import io
import re
from datetime import datetime

import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Data Cleaner Agent", page_icon="🧹", layout="wide")

st.title("🧹 Data Cleaner Agent")
st.caption("Upload a Sales or Customer dataset, inspect data quality, clean it, and export the results.")

with st.sidebar:
    st.header("Cleaning settings")
    dataset_type = st.selectbox("Dataset type", ["Sales", "Customer", "Other"])
    missing_strategy = st.selectbox(
        "Missing-value strategy",
        ["Keep missing values", "Drop rows with any missing value", "Fill numeric with median + text with mode", "Fill all missing values with 0 / Unknown"],
    )
    remove_duplicates = st.checkbox("Remove exact duplicate rows", value=True)
    trim_text = st.checkbox("Trim extra spaces in text", value=True)
    standardize_columns = st.checkbox("Standardize column names", value=True)
    convert_numeric = st.checkbox("Convert numeric-looking text columns", value=False)

uploaded = st.file_uploader("Upload a CSV or Excel file", type=["csv", "xlsx", "xls"])

def read_upload(file):
    if file.name.lower().endswith(".csv"):
        # Try common encodings and delimiter detection.
        try:
            return pd.read_csv(file)
        except UnicodeDecodeError:
            file.seek(0)
            return pd.read_csv(file, encoding="latin-1")
    return pd.read_excel(file)

def standardize_name(name):
    name = str(name).strip().lower()
    name = re.sub(r"[^a-z0-9]+", "_", name)
    return re.sub(r"_+", "_", name).strip("_") or "unnamed_column"

def make_excel_bytes(dataframe, report_df):
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        dataframe.to_excel(writer, index=False, sheet_name="Cleaned_Data")
        report_df.to_excel(writer, index=False, sheet_name="Quality_Report")
    output.seek(0)
    return output.getvalue()

def make_quality_report(df, label):
    rows = []
    for col in df.columns:
        rows.append({
            "dataset_type": label,
            "column": str(col),
            "data_type": str(df[col].dtype),
            "missing_count": int(df[col].isna().sum()),
            "missing_percent": round(float(df[col].isna().mean() * 100), 2),
            "unique_values": int(df[col].nunique(dropna=True)),
        })
    return pd.DataFrame(rows)

if uploaded is None:
    st.info("Start by uploading a CSV or Excel dataset. You can also try the sample datasets below.")
    sample_choice = st.selectbox("Or load a built-in sample", ["None", "Sample Sales", "Sample Customers"])
    if sample_choice == "Sample Sales":
        df = pd.read_csv(Path(__file__).parent / "sample_data" / "sales_sample.csv")
        dataset_type = "Sales"
    elif sample_choice == "Sample Customers":
        df = pd.read_csv(Path(__file__).parent / "sample_data" / "customer_sample.csv")
        dataset_type = "Customer"
    else:
        df = None
else:
    df = read_upload(uploaded)

if df is not None:
    if df.empty:
        st.error("The uploaded dataset has no rows.")
        st.stop()

    st.subheader("1. Data preview")
    st.write(f"Dataset type: **{dataset_type}** · Rows: **{len(df):,}** · Columns: **{len(df.columns):,}**")
    st.dataframe(df.head(20), use_container_width=True)

    before_rows, before_cols = df.shape
    before_duplicates = int(df.duplicated().sum())
    before_missing = int(df.isna().sum().sum())
    before_report = make_quality_report(df, dataset_type)

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Rows", f"{before_rows:,}")
    col2.metric("Columns", f"{before_cols:,}")
    col3.metric("Missing cells", f"{before_missing:,}")
    col4.metric("Duplicate rows", f"{before_duplicates:,}")

    st.subheader("2. Data quality report")
    st.dataframe(before_report, use_container_width=True)

    cleaned = df.copy()
    actions = []

    if trim_text:
        text_cols = cleaned.select_dtypes(include=["object", "string"]).columns
        for col in text_cols:
            cleaned[col] = cleaned[col].map(lambda x: x.strip() if isinstance(x, str) else x)
        actions.append(f"Trimmed surrounding spaces in {len(text_cols)} text column(s).")

    if standardize_columns:
        old_columns = list(cleaned.columns)
        cleaned.columns = [standardize_name(c) for c in cleaned.columns]
        actions.append("Standardized column names to lowercase_with_underscores.")
        # If normalization creates duplicate names, make names unique.
        seen = {}
        unique_cols = []
        for c in cleaned.columns:
            seen[c] = seen.get(c, 0) + 1
            unique_cols.append(c if seen[c] == 1 else f"{c}_{seen[c]}")
        cleaned.columns = unique_cols

    if convert_numeric:
        converted = []
        for col in cleaned.select_dtypes(include=["object", "string"]).columns:
            candidate = pd.to_numeric(cleaned[col].astype(str).str.replace(",", "", regex=False), errors="coerce")
            nonempty = cleaned[col].notna().sum()
            if nonempty and candidate.notna().sum() / nonempty >= 0.8:
                cleaned[col] = candidate
                converted.append(col)
        actions.append("Converted numeric-looking columns: " + (", ".join(converted) if converted else "none detected") + ".")

    if remove_duplicates:
        before = len(cleaned)
        cleaned = cleaned.drop_duplicates()
        actions.append(f"Removed {before - len(cleaned):,} exact duplicate row(s).")

    if missing_strategy == "Drop rows with any missing value":
        before = len(cleaned)
        cleaned = cleaned.dropna()
        actions.append(f"Dropped {before - len(cleaned):,} row(s) containing missing values.")
    elif missing_strategy == "Fill numeric with median + text with mode":
        for col in cleaned.columns:
            if pd.api.types.is_numeric_dtype(cleaned[col]):
                if cleaned[col].isna().any():
                    median = cleaned[col].median()
                    if pd.notna(median):
                        cleaned[col] = cleaned[col].fillna(median)
            else:
                if cleaned[col].isna().any():
                    modes = cleaned[col].mode(dropna=True)
                    if not modes.empty:
                        cleaned[col] = cleaned[col].fillna(modes.iloc[0])
        actions.append("Filled numeric missing values with median and text missing values with mode where available.")
    elif missing_strategy == "Fill all missing values with 0 / Unknown":
        for col in cleaned.columns:
            cleaned[col] = cleaned[col].fillna(0 if pd.api.types.is_numeric_dtype(cleaned[col]) else "Unknown")
        actions.append("Filled numeric missing values with 0 and non-numeric missing values with 'Unknown'.")
    else:
        actions.append("Kept missing values unchanged.")

    after_report = make_quality_report(cleaned, dataset_type)
    st.subheader("3. Cleaning results")
    a, b, c, d = st.columns(4)
    a.metric("Cleaned rows", f"{len(cleaned):,}", delta=f"{len(cleaned)-before_rows:,} vs original")
    b.metric("Remaining missing cells", f"{int(cleaned.isna().sum().sum()):,}")
    c.metric("Remaining duplicate rows", f"{int(cleaned.duplicated().sum()):,}")
    d.metric("Rows removed", f"{before_rows-len(cleaned):,}")

    with st.expander("Cleaning log", expanded=True):
        for action in actions:
            st.write("• " + action)

    st.dataframe(cleaned.head(30), use_container_width=True)

    st.subheader("4. Download deliverables")
    csv_bytes = cleaned.to_csv(index=False).encode("utf-8-sig")
    report_csv = after_report.to_csv(index=False).encode("utf-8-sig")
    excel_bytes = make_excel_bytes(cleaned, after_report)
    report_text = (
        "DATA CLEANER AGENT - QUALITY SUMMARY\n"
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"Dataset type: {dataset_type}\n"
        f"Original rows: {before_rows}\nOriginal columns: {before_cols}\n"
        f"Original missing cells: {before_missing}\nOriginal duplicate rows: {before_duplicates}\n"
        f"Cleaned rows: {len(cleaned)}\nCleaned columns: {len(cleaned.columns)}\n"
        f"Remaining missing cells: {int(cleaned.isna().sum().sum())}\n"
        f"Remaining duplicate rows: {int(cleaned.duplicated().sum())}\n\n"
        "Cleaning actions:\n" + "\n".join("- " + x for x in actions) + "\n"
    ).encode("utf-8")

    x, y, z = st.columns(3)
    x.download_button("⬇️ Download cleaned CSV", csv_bytes, file_name="cleaned_dataset.csv", mime="text/csv", use_container_width=True)
    y.download_button("⬇️ Download Excel workbook", excel_bytes, file_name="data_cleaner_output.xlsx", mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True)
    z.download_button("⬇️ Download quality summary", report_text, file_name="data_quality_summary.txt", mime="text/plain", use_container_width=True)

    st.caption("Important: review the quality report before using cleaned data. Automatic filling/removal can change meaning; keep a copy of the original dataset.")
