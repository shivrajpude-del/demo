# Data Cleaner Agent — Advanced Web App

A beginner-friendly Streamlit app that audits and cleans Sales and Customer datasets.

## Features
- Upload CSV, XLSX, or XLS files
- Inspect data preview, missing values, data types, unique values, and duplicate rows
- Trim surrounding whitespace in text columns
- Standardize column names
- Optional numeric-looking text conversion
- Remove exact duplicate rows
- Choose how missing values are handled
- Export cleaned CSV, Excel workbook, and quality summary
- Includes sample Sales and Customer datasets

## Setup (Windows)
1. Install Python 3.10 or newer from https://www.python.org/downloads/
2. Extract this ZIP folder.
3. Open Command Prompt in the extracted `data_cleaner_agent` folder.
4. Create a virtual environment:
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   ```
5. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
6. Start the app:
   ```bash
   streamlit run app.py
   ```
7. Your browser should open the app. If it does not, open the local URL shown in the terminal (usually http://localhost:8501).

## Setup (Android)
The app needs a Python environment that supports Streamlit. The easiest route is to upload this project to a private/public GitHub repository and deploy it using Streamlit Community Cloud. Do not upload private customer data to a public repository.

## How to use
1. Choose Sales, Customer, or Other in the sidebar.
2. Upload a CSV/Excel file, or choose one of the built-in sample datasets.
3. Review the original preview and quality report.
4. Choose cleaning options in the sidebar.
5. Review the cleaning log and cleaned preview.
6. Download the cleaned CSV, Excel workbook, and quality summary.

## Important data-quality notes
- Dropping rows with missing values may remove useful records.
- Filling numeric columns with median is a general-purpose option, not always the right business rule.
- Filling every numeric missing value with zero can be misleading; use only when zero is a valid meaning.
- Exact duplicate detection checks whether all values in a row match. Business duplicates may need a key such as `order_id` or `customer_id`.
- Always keep the original file and validate the cleaned output.

## Suggested interview explanation
"I built a Streamlit-based Data Cleaner Agent using Python, Pandas, and NumPy. It profiles incoming CSV/Excel files, reports missing values and duplicates, applies configurable cleaning rules, logs the actions, and exports an analysis-ready dataset plus a quality report. I included safeguards so users can review the data and choose how missing values are handled."

## Suggested project structure
```
data_cleaner_agent/
├── app.py
├── requirements.txt
├── README.md
└── sample_data/
    ├── sales_sample.csv
    └── customer_sample.csv
```
