# Data Cleaner Agent — Project Summary

## Problem
Raw sales and customer datasets often contain missing values, duplicate rows, inconsistent text spacing, and inconsistent column names. These issues can affect analysis and reporting.

## Solution
A Streamlit web app built with Python, Pandas, and NumPy. Users upload CSV/Excel files, inspect a quality report, select cleaning rules, and export the cleaned dataset and summary.

## Inputs
- Sales dataset (orders, product, quantity, unit price, revenue, city)
- Customer dataset (customer ID, name, email, age, city, segment)

## Outputs
- Cleaned CSV
- Excel workbook with Cleaned_Data and Quality_Report sheets
- Data-quality summary text file
- In-app cleaning log

## Validation
The app displays original and cleaned row counts, missing cells, duplicate rows, and per-column missing percentages. Users can preview data before exporting.

## Limitations / future improvements
- Add business-key duplicate rules (for example, Order ID or Customer ID).
- Add date parsing and invalid-email checks.
- Add downloadable PDF report and a database connector.
- Add authentication if deployed for team use.
